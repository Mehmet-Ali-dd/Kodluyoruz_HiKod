import 'package:flutter/material.dart';
import 'prob_içeriği.dart';

class ProblemlerSayfasi extends StatelessWidget {
  final List<String> problemler = [
    "İzinsiz Fotoğraf Paylaşımı",
    "Kişisel Bilgi Paylaşımı",
    "Tehdit",
    "Trolleme",
    "Sahte Hesap",
    "Oyun İçi Zorbalama",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Problemler")),
      body: ListView.builder(
        itemCount: problemler.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(problemler[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProbIcerigiSayfasi(problemName: problemler[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
