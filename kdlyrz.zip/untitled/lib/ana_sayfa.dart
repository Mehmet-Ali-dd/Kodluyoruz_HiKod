import 'package:flutter/material.dart';
import 'problemler.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yardım Çağrı Uygulaması',
      home: AnaSayfa(),
    );
  }
}

class AnaSayfa extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Yardım Çağrı Uygulaması")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text("Yardım Çağrı Uygulaması", style: TextStyle(fontSize: 35)),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("Yardım Al"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProblemlerSayfasi()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

